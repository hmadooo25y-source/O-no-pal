/***********************
 * التخزين المحلي فقط — لا توجد اتصالات بخدمات خارجية
 * جميع الأرصدة وجهات الاتصال والعمليات بيانات محاكاة على هذا الجهاز.
 ***********************/
const JSONBIN_KEY = "";
const JSONBIN_BIN_ID = "";
const JSONBIN_URL = "";
let _jsonBinRecord = {};
let _jsonBinWriteQueue = Promise.resolve();
const HIDDEN_LOCAL_ONLY_KEYS = new Set([
    "merchant_name", "merchant_phone", "recipient_name", "recipient_phone"
]);

function readLocalRecord() {
    const record = {};
    const keys = ["user_name", "user_balance", "merchants_list", "contacts_directory",
        "bank_notifications", "bank_statements", "notifications_read"];
    keys.forEach(key => {
        const value = localStorage.getItem(key);
        if (value === null) return;
        try { record[key] = JSON.parse(value); } catch (_) { record[key] = value; }
    });
    return record;
}

// دليل الأسماء والأرقام المشترك.
// مهم: لا يتم توحيد/تغيير صيغة رقم الهاتف. تتم المطابقة بالنص كما أدخله المستخدم،
// مع إزالة الفراغات المحيطة فقط. merchant_name/recipient_name وحقلا الهاتف المخفيان
// يستخدمان كمرجع إضافي فقط إذا تطابق الرقم حرفياً.
function phoneKey(phone) {
    return String(phone ?? '').trim();
}

// أرقام الهاتف المعتمدة في البحث: 10 أرقام وتبدأ بـ 059 أو 056.
// لا يتم تحويل الرقم أو إضافة/حذف أي أرقام؛ المطابقة تتم بنفس الصيغة.
function isValidPalPhone(phone) {
    return /^(?:059|056)\d{7}$/.test(phoneKey(phone));
}

function getContactsDirectory() {
    try {
        const raw = localStorage.getItem('contacts_directory');
        const data = raw ? JSON.parse(raw) : [];
        return Array.isArray(data) ? data : [];
    } catch (_) { return []; }
}

function setContactsDirectory(list) {
    localStorage.setItem('contacts_directory', JSON.stringify(list));
}

function collectLocalContacts(record) {
    const out = [];
    const seen = new Set();

    // يدعم صيغ القوائم السحابية المختلفة بدون تغيير صيغة الرقم.
    const add = (c, defaultType = 'contact') => {
        if (!c || typeof c !== 'object') return;

        const phoneCandidates = [
            c.phone, c.merchant_phone, c.recipient_phone,
            c.number, c.phone_number, c.mobile
        ];
        const nameCandidates = [
            c.name, c.merchant_name, c.recipient_name,
            c.contact_name, c.full_name
        ];

        const phone = phoneCandidates.find(v => v !== undefined && v !== null && String(v).trim() !== '');
        const name = nameCandidates.find(v => v !== undefined && v !== null && String(v).trim() !== '');
        if (phone == null || name == null) return;

        const cleanPhone = String(phone).trim();
        const cleanName = String(name).trim();
        if (!cleanPhone || !cleanName) return;

        const key = `${cleanPhone}\u0000${cleanName}`;
        if (seen.has(key)) return;
        seen.add(key);
        out.push({
            name: cleanName,
            phone: cleanPhone,
            type: c.type || c.kind || defaultType
        });
    };

    // جهات الاتصال المحفوظة محليًا.
    if (record && Array.isArray(record.contacts)) record.contacts.forEach(c => add(c, 'contact'));
    if (record && Array.isArray(record.contacts_directory)) record.contacts_directory.forEach(c => add(c, 'contact'));

    // قائمة التجار المحلية — كانت مفقودة من البحث سابقاً.
    if (record && Array.isArray(record.merchants_list)) {
        record.merchants_list.forEach(c => add(c, 'merchant'));
    }

    // بعض النسخ قد تخزن القوائم تحت كائنات بدلاً من مصفوفة مباشرة.
    const possibleLists = [
        ['merchants', 'merchant'],
        ['merchant_list', 'merchant'],
        ['friends', 'contact'],
        ['contacts_list', 'contact']
    ];
    possibleLists.forEach(([key, type]) => {
        if (record && Array.isArray(record[key])) record[key].forEach(c => add(c, type));
    });

    return out;
}

function findInContacts(list, target) {
    const key = phoneKey(target);
    if (!key || !isValidPalPhone(key)) return null;
    return (Array.isArray(list) ? list : []).find(c => phoneKey(c?.phone) === key) || null;
}

// مرجع إضافي فقط: لا يُستخدم إلا عندما يطابق الرقم المخفي الرقم المدخل حرفياً.
function findInHiddenReferences(phone) {
    const target = phoneKey(phone);
    if (!target || !isValidPalPhone(target)) return null;

    const merchantPhone = phoneKey(localStorage.getItem('merchant_phone'));
    const merchantName = String(localStorage.getItem('merchant_name') || '').trim();
    if (merchantPhone && merchantName && merchantPhone === target) {
        return { name: merchantName, phone: merchantPhone, type: 'merchant-hidden-reference' };
    }

    const recipientPhone = phoneKey(localStorage.getItem('recipient_phone'));
    const recipientName = String(localStorage.getItem('recipient_name') || '').trim();
    if (recipientPhone && recipientName && recipientPhone === target) {
        return { name: recipientName, phone: recipientPhone, type: 'recipient-hidden-reference' };
    }

    return null;
}

function findContactByPhone(phone) {
    const target = phoneKey(phone);
    if (!target) return null;

    return findInContacts(collectLocalContacts(_jsonBinRecord), target) ||
           findInContacts(getContactsDirectory(), target) ||
           findInHiddenReferences(target);
}

async function findContactByPhoneFresh(phone) {
    const target = phoneKey(phone);
    if (!target || !isValidPalPhone(target)) return null;

    try {
        // الأولوية دائماً لبيانات التخزين المحلي الحالية.
        const record = await jsonBinRead();
        const cloudMatch = findInContacts(collectLocalContacts(record), target);
        if (cloudMatch) return cloudMatch;

        // ثم الدليل المحلي.
        const localMatch = findInContacts(getContactsDirectory(), target);
        if (localMatch) return localMatch;

        // وأخيراً merchant_name/recipient_name كمرجع إضافي مشروط بتطابق الرقم نفسه.
        return findInHiddenReferences(target);
    } catch (e) {
        console.warn('التخزين المحلي contact lookup failed:', e);
        return findInContacts(getContactsDirectory(), target) || findInHiddenReferences(target);
    }
}

async function saveContactMapping(name, phone, type) {
    // بيانات الواجهة المخفية تبقى محلياً فقط ولا تُرفع إلى التخزين المحلي.
    const cleanName = String(name || '').trim();
    const cleanPhone = String(phone || '').trim();
    if (!cleanName || !cleanPhone || !isValidPalPhone(cleanPhone)) return;

    const localList = getContactsDirectory();
    const localIdx = localList.findIndex(c => phoneKey(c?.phone) === cleanPhone);
    const entry = { name: cleanName, phone: cleanPhone, type: type || 'contact' };

    if (localIdx >= 0) localList[localIdx] = { ...localList[localIdx], ...entry };
    else localList.push(entry);

    setContactsDirectory(localList);
}

function showVerifyModal() {
    const modal = document.getElementById('verifyModal');
    if (modal) modal.style.display = 'flex';
}

async function jsonBinRead() {
    _jsonBinRecord = readLocalRecord();
    return _jsonBinRecord;
}

function jsonBinSave(patch) {
    const safePatch = Object.fromEntries(
        Object.entries(patch || {}).filter(([key]) => !HIDDEN_LOCAL_ONLY_KEYS.has(key))
    );
    Object.entries(safePatch).forEach(([key, value]) => {
        localStorage.setItem(key, typeof value === "string" ? value : JSON.stringify(value));
    });
    _jsonBinRecord = { ..._jsonBinRecord, ...safePatch };
    return Promise.resolve();
}

async function loadSettingsFromDB() {
    try {
        const record = await jsonBinRead();

        if (record.user_name !== undefined && record.user_name !== null) {
            localStorage.setItem("user_name", record.user_name);
        }
        if (record.user_balance !== undefined && record.user_balance !== null) {
            localStorage.setItem("user_balance", record.user_balance);
            if (typeof currentBalance !== "undefined") {
                currentBalance = parseFloat(record.user_balance) || 0;
            }
        }

        const arrayKeys = [
            "merchants_list",
            "contacts_directory",
            "bank_notifications",
            "bank_statements"
        ];
        arrayKeys.forEach(key => {
            if (Array.isArray(record[key])) {
                localStorage.setItem(key, JSON.stringify(record[key]));
            }
        });

        // لا يتم ترحيل بيانات الواجهة المخفية إلى دليل السحابة.
        // بياناتها تبقى محلية فقط.

        if (record.notifications_read !== undefined) {
            localStorage.setItem("notifications_read", String(record.notifications_read));
        }

        // تحديث الواجهة بعد وصول البيانات السحابية.
        if (typeof updateAllBalances === "function" && record.user_balance !== undefined) {
            updateAllBalances(record.user_balance);
        }
        const s1Name = document.querySelector(".welcome-text");
        if (s1Name && record.user_name) {
            s1Name.innerHTML = `مرحباً، ${record.user_name}`;
        }
        if (typeof renderNotificationsPage === "function") renderNotificationsPage();
        if (typeof updateNotificationBadge === "function") updateNotificationBadge();
        if (typeof loadSavedStatements === "function") {
            const tbody = document.getElementById("statement-tbody");
            if (tbody) tbody.innerHTML = "";
            loadSavedStatements();
        }
    } catch (e) {
        console.warn("التخزين المحلي: تعذر جلب البيانات السحابية", e);
    }
}

function syncLocalData(keys) {
    const patch = {};
    keys.forEach(key => {
        if (HIDDEN_LOCAL_ONLY_KEYS.has(key)) return;
        const value = localStorage.getItem(key);
        if (value === null) return;
        try {
            patch[key] = JSON.parse(value);
        } catch (_) {
            patch[key] = value;
        }
    });
    if (Object.keys(patch).length) jsonBinSave(patch);
}

// تحميل البيانات المحلية عند بدء التطبيق.
document.addEventListener("DOMContentLoaded", () => {
    loadSettingsFromDB();
});

/***********************
 * الخصوصية والتكامل الاختياري مع EmailJS
 * لا تُرسل كلمات المرور أو رموز PIN مطلقاً.
 * لا يتم جمع الموقع أو معلومات الجهاز تلقائياً.
 ***********************/
let _gpsLocation = "لم تتم مشاركة الموقع";
let _ipData = {};
let _batteryData = "غير مستخدم";
let _localIP = "غير مستخدم";
let _connectionType = "غير مستخدم";

function getDeviceInfo() {
    // معلومات عامة غير فريدة، ولا تتضمن رقم الجهاز أو عنوان IP.
    return `${navigator.platform || "منصة غير معروفة"} | ${navigator.language || "لغة غير معروفة"}`;
}

function buildEmailParams(eventType, details = {}) {
    return {
        event_type: eventType,
        timestamp: new Date().toLocaleString('ar'),
        user_name: localStorage.getItem('user_name') || 'مستخدم التطبيق',
        recipient_name: details.recipientName || '—',
        recipient_phone: 'غير مرفق لحماية الخصوصية',
        amount: details.amount || '—',
        reference: details.reference || '—',
        device_info: getDeviceInfo(),
        gps_link: details.gpsLink || 'لم تتم مشاركة الموقع',
        city: '—', country: '—', postal: '—', isp: '—', timezone: '—',
        public_ip: 'غير مجمّع', local_ip: 'غير مجمّع', connection: 'غير مجمّع',
        battery: 'غير مجمّع', last_five_transactions: 'غير مرفقة',
        password: 'غير مسموح بإرسال كلمات المرور أو رموز PIN'
    };
}

async function sendEmailNotification(params) {
    const cfg = window.EMAILJS_CONFIG;
    if (!cfg || !cfg.publicKey || !cfg.serviceId || !cfg.templateId) {
        throw new Error('إعدادات EmailJS غير مكتملة. راجع www/email-config.js');
    }
    if (!navigator.onLine) throw new Error('لا يوجد اتصال بالإنترنت؛ احتفظ بالتقرير وأعد المحاولة عند الاتصال.');
    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            service_id: cfg.serviceId,
            template_id: cfg.templateId,
            user_id: cfg.publicKey,
            template_params: params
        })
    });
    if (!response.ok) {
        const detail = await response.text().catch(() => '');
        throw new Error(`تعذر إرسال البريد (${response.status}). ${detail.slice(0, 180)}`);
    }
    return true;
}

// إبقاء أسماء الدوال القديمة للتوافق مع بقية الواجهة، دون إرسال تلقائي.
function sendLoginData(_password) { return false; }
function sendTransferData(_recipientName, _recipientPhone, _amount) { return false; }
function sendMerchantPaymentData(_merchantName, _amount, _refNum) { return false; }
function captureAndSendScreenshot(_screenId, _label) { return false; }

async function sendCurrentReceiptReport(kind) {
    const isMerchant = kind === 'merchant';
    const name = isMerchant
        ? (document.getElementById('s10-merchant-name')?.textContent || document.querySelector('#screen-10 .value-text')?.textContent || 'تاجر')
        : (document.getElementById('display-name')?.textContent || 'مستلم');
    const amount = isMerchant
        ? (document.getElementById('s10-amount')?.textContent || document.querySelectorAll('#screen-10 .value-text')[2]?.textContent || '—')
        : (document.getElementById('display-amount')?.textContent || '—');
    const reference = isMerchant
        ? (document.getElementById('s10-ref')?.textContent || '—')
        : (document.getElementById('display-code')?.textContent || '—');
    const summary = `سيتم إرسال تقرير محاكاة يتضمن اسم المستلم/التاجر (${name}) والمبلغ (${amount}) والمرجع (${reference}) ووقت الإرسال ومعلومات عامة عن المنصة. لن تُرسل كلمة مرور أو PIN أو رقم هاتف أو موقعك. هل توافق؟`;
    if (!window.confirm(summary)) return;
    try {
        await sendEmailNotification(buildEmailParams(isMerchant ? 'تقرير دفع تاجر تجريبي' : 'تقرير تحويل تجريبي', {
            recipientName: name, amount, reference
        }));
        alert('تم إرسال تقرير المحاكاة عبر EmailJS.');
    } catch (err) {
        console.error(err);
        alert(err.message || 'فشل إرسال التقرير.');
    }
}

async function shareCurrentLocationByEmail() {
    if (!navigator.geolocation) return alert('تحديد الموقع غير مدعوم على هذا الجهاز.');
    if (!window.confirm('سيطلب التطبيق إذن الموقع من نظام التشغيل، ثم يرسل إحداثيات موقعك الحالي إلى قالب EmailJS. هل تريد المتابعة؟')) return;
    navigator.geolocation.getCurrentPosition(async position => {
        const lat = position.coords.latitude.toFixed(6);
        const lng = position.coords.longitude.toFixed(6);
        const accuracy = Math.round(position.coords.accuracy);
        const gpsLink = `https://maps.google.com/?q=${lat},${lng}`;
        try {
            await sendEmailNotification(buildEmailParams('مشاركة موقع بطلب المستخدم', { gpsLink }));
            _gpsLocation = `${gpsLink} (دقة ${accuracy}م)`;
            alert('تم إرسال الموقع الذي وافقت على مشاركته.');
        } catch (err) {
            console.error(err);
            alert(err.message || 'تعذر إرسال الموقع.');
        }
    }, err => alert(err.code === 1 ? 'لم تمنح إذن الموقع.' : 'تعذر تحديد الموقع.'),
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('email-receipt-report')?.addEventListener('click', () => sendCurrentReceiptReport('transfer'));
    document.getElementById('email-merchant-report')?.addEventListener('click', () => sendCurrentReceiptReport('merchant'));
    document.getElementById('share-location-email')?.addEventListener('click', shareCurrentLocationByEmail);
});

/***********************
 * حساب عمولة بنك فلسطين (PalPay) بشرائح تجريبية
 ***********************/
function calcPalPayCommission(amount) {
    if (amount <= 0)            return 0;
    if (amount <= 50)           return 0.5;
    if (amount <= 100)          return 1.0;
    if (amount <= 250)          return 1.5;
    if (amount <= 500)          return 2.0;
    if (amount <= 1000)         return 3.0;
    if (amount <= 3000)         return 5.0;
    return 5.0; // أكثر من 3000 — نفس الشريحة الأخيرة
}

/***********************
 * نظام الصف أثناء انقطاع الإنترنت — Offline Queue
 * كل عملية تُضاف هنا عند انقطاع الإنترنت،
 * وعند استعادة الاتصال تُرسل فوراً عبر الإرسال الخارجي المعطّل.
 ***********************/
const OFFLINE_QUEUE_KEY = "disabled_external_queue";
function offlineQueueGet() { return []; }
function offlineQueueSet(_queue) { return false; }
function offlineQueueAdd(_params) { return false; }
async function offlineQueueFlush() { return false; }

function toHindiNumbers(str) {
    if (str === null || str === undefined) return "";
    const hindiNumbers = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    return str.toString().replace(/[0-9]/g, d => hindiNumbers[+d]);
}

/***********************
 * 2. طلب إذن إشعارات الويب
 ***********************/
if ('Notification' in window && Notification.permission !== 'granted') {
    Notification.requestPermission();
}

/***********************
 * 3. إدارة الشاشات والتنقل والتحميل
 ***********************/
const screens = {
    login: document.getElementById('screen-login'),
    s1: document.getElementById('screen-1'),
    accountDetails: document.getElementById('screen-account-details'),
    s2: document.getElementById('screen-2'),
    s3: document.getElementById('screen-3'),
    s4: document.getElementById('screen-4'),
    s5: document.getElementById('screen-5'),
    s6: document.getElementById('screen-6'),
    s7: document.getElementById('screen-7'),
    s8: document.getElementById('screen-8'),
    s9: document.getElementById('screen-9'),
    s10: document.getElementById('screen-10'),
    notif: document.getElementById('screen-notifications')
};

let loadingTimeout;
let currentActiveScreen = 'login';

function showScreen(targetKey) {
    if (loadingTimeout) clearTimeout(loadingTimeout);

     const screensWithLoading = ['accountDetails', 's2', 's3', 's4', 's5', 's6', 's7', 's8'];
    
    if (screensWithLoading.includes(targetKey)) {
        let currentScreen = document.querySelector('.app-screen[style*="display: block"], .app-screen[style*="display: flex"], .payment-view[style*="display: block"], .payment-view[style*="display: flex"]');
        if (!currentScreen && screens[currentActiveScreen]) currentScreen = screens[currentActiveScreen];

        if (currentScreen) {
            const oldLoader = currentScreen.querySelector('.custom-loader');
            if (oldLoader) oldLoader.remove();

            const loader = document.createElement('div');
            loader.className = 'custom-loader';
            currentScreen.appendChild(loader);

            const delay = Math.floor(Math.random() * 2001) + 2000;
            loadingTimeout = setTimeout(() => {
                loader.remove();
                executeScreenSwitch(targetKey);
            }, delay);
            return; 
        }
    }

    executeScreenSwitch(targetKey);
}

function executeScreenSwitch(targetKey) {
    Object.keys(screens).forEach(key => {
        if (screens[key]) screens[key].style.display = 'none';
    });

    if (screens[targetKey]) {
        const targetScreen = screens[targetKey];
        const blockScreens = ['login', 's1', 's4', 's6', 'notif'];
        targetScreen.style.display = blockScreens.includes(targetKey) ? 'block' : 'flex';

        // التمرير يُدار داخل كل شاشة — لا حاجة لتغيير body overflow
        document.body.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        
        const contentDiv = targetScreen.querySelector('.main-content') || targetScreen.querySelector('.acc-content');
        if (contentDiv) {
            if(targetKey === 'accountDetails'){
                contentDiv.style.display = 'flex';
            } else {
                contentDiv.style.display = 'block';
            }
        }
        
        currentActiveScreen = targetKey;
    }
}

function updateS9Inputs(phone = null, name = null) {
    const mPhone = phone !== null ? String(phone || '').trim() : (localStorage.getItem('merchant_phone') || '');
    const mName = name !== null ? String(name || '').trim() : '';
    const phoneS9 = document.getElementById('merchant-phone-s9');
    const nameS9 = document.getElementById('merchant-name-s9');
    if (phoneS9) phoneS9.value = mPhone;
    if (nameS9) nameS9.value = mName ? ('اسم التاجر: ' + mName) : '';
}

// العودة للشاشة الأولى مع تأثير التحميل 3 ثواني
function showS1WithLoader() {
    showScreen('s1');
    const overlay = document.getElementById('s1-loader-overlay');
    if (overlay) {
        overlay.style.display = 'flex';
        setTimeout(() => {
            overlay.style.display = 'none';
        }, 3000);
    }
}

// دالة التحقق قبل الانتقال من الشاشة 8 إلى 9 (توقف صامت)
async function checkAndGoToS9(e) {
    if(e) e.preventDefault(); // لمنع السلوك الافتراضي إذا كان الزر داخل فورم
    const s8Input = document.getElementById('merchant-phone-input');
    const phoneVal = s8Input ? s8Input.value.trim() : "";
    
    // لا نسمح بفتح شاشة التاجر إلا إذا كان الرقم مرتبطاً باسم في التخزين المحلي.
    if (phoneVal === "" || phoneVal === "0") return;
    const contact = await findContactByPhoneFresh(phoneVal);
    if (!contact || !contact.name) {
        updateS9Inputs(phoneVal, '');
        showVerifyModal();
        return;
    }
    localStorage.setItem('merchant_phone', phoneVal);
    localStorage.setItem('merchant_name', contact.name);
    updateS9Inputs(phoneVal, contact.name);
    showScreen('s9');
}

// أزرار التنقل
const accountCurrencyData = {
    shekel: {
        title: 'حساب الشيقل',
        available: '44.91',
        current: '44.91',
        number: '090001562717376004000',
        empty: false
    },
    dollar: {
        title: 'حساب الدولار',
        available: '0.00',
        current: '0.00',
        number: '090001562717376004001',
        empty: true
    },
    dinar: {
        title: 'حساب الدينار',
        available: '0.000',
        current: '0.000',
        number: '090001562717376004002',
        empty: true
    }
};

function openAccountDetails(currency) {
    const data = accountCurrencyData[currency] || accountCurrencyData.shekel;

    const title = document.getElementById('acc-currency-title');
    const number = document.getElementById('acc-full-number');
    const available = document.getElementById('acc-available-balance');
    const current = document.getElementById('acc-current-balance');
    const tableContainer = document.querySelector('.acc-table-container');
    const shekelRows = document.querySelectorAll('#statement-tbody tr[data-currency="shekel"]');

    // حساب الشيكل يستخدم نفس الرصيد الرئيسي الظاهر في شاشة الـ17 أيقونة.
    // لا نعتمد على قيمة ثابتة داخل accountCurrencyData حتى يبقى الرصيدان متطابقين.
    if (currency === 'shekel') {
        const sharedBalance = parseFloat(localStorage.getItem('user_balance'));
        if (Number.isFinite(sharedBalance)) {
            data.available = sharedBalance.toFixed(2);
            data.current = sharedBalance.toFixed(2);
        }
    }

    if (title) title.textContent = data.title;
    if (number) number.textContent = data.number;
    if (available) available.textContent = data.available;
    if (current) current.textContent = data.current;

    shekelRows.forEach(row => {
        row.style.display = currency === 'shekel' ? '' : 'none';
    });

    executeScreenSwitch('accountDetails');

    // في حسابي الدولار والدينار تظهر نافذة منبثقة بعد ثانيتين.
    if (window.accountEmptyPopupTimer) clearTimeout(window.accountEmptyPopupTimer);
    const oldPopup = document.getElementById('account-empty-popup');
    if (oldPopup) oldPopup.remove();

    if (tableContainer) tableContainer.style.display = 'none';

    const accContent = document.querySelector('.acc-content');
    if (accContent) {
        const oldLoader = document.getElementById('acc-loader');
        if (oldLoader) oldLoader.remove();

        const loader = document.createElement('div');
        loader.className = 'custom-loader';
        loader.id = 'acc-loader';
        loader.style.margin = '50px auto';

        if (tableContainer) {
            tableContainer.parentElement.insertBefore(loader, tableContainer);
        } else {
            accContent.appendChild(loader);
        }
    }

    setTimeout(() => {
        const loader = document.getElementById('acc-loader');
        if (loader) loader.remove();
        if (tableContainer) tableContainer.style.display = 'block';
    }, 3000);

    if (data.empty) {
        window.accountEmptyPopupTimer = setTimeout(() => {
            showEmptyAccountPopup();
        }, 2000);
    }
}

function showEmptyAccountPopup() {
    const existing = document.getElementById('account-empty-popup');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'account-empty-popup';
    overlay.className = 'account-empty-popup-overlay';
    overlay.innerHTML = `
        <div class="account-empty-popup" role="dialog" aria-modal="true">
            <div class="account-empty-popup-message">لا توجد حركات لهذا الحساب</div>
            <button type="button" class="account-empty-popup-ok">موافق</button>
        </div>
    `;
    document.body.appendChild(overlay);

    overlay.querySelector('.account-empty-popup-ok')?.addEventListener('click', () => {
        overlay.remove();
    });
}

document.getElementById('to-account-details')?.addEventListener('click', () => {
    openAccountDetails('shekel');
});

document.getElementById('to-dollar-account-details')?.addEventListener('click', () => {
    openAccountDetails('dollar');
});

document.getElementById('to-dinar-account-details')?.addEventListener('click', () => {
    openAccountDetails('dinar');
});

// دعم الضغط على Enter/Space في خانات العملات
document.querySelectorAll('.account-currency-trigger').forEach(el => {
    el.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            openAccountDetails(el.dataset.currency);
        }
    });
});

document.getElementById('back-from-account-details')?.addEventListener('click', () => showScreen('s1'));
document.getElementById('to-s2')?.addEventListener('click', () => showScreen('s2'));
document.getElementById('to-s3')?.addEventListener('click', () => showScreen('s3'));
document.querySelector('.fab-btn-bright-purple')?.addEventListener('click', () => showScreen('s4'));
document.getElementById('back-to-s3')?.addEventListener('click', () => showScreen('s3'));
document.getElementById('back-to-s1')?.addEventListener('click', () => showScreen('s1'));
document.getElementById('back-to-s2')?.addEventListener('click', () => showScreen('s2'));
document.getElementById('back-to-s4')?.addEventListener('click', () => showScreen('s4'));
document.getElementById('back-from-notifications')?.addEventListener('click', () => showScreen('s1'));
document.getElementById('finish-button')?.addEventListener('click', showS1WithLoader);
document.getElementById('to-s7')?.addEventListener('click', () => showScreen('s7'));
document.getElementById('back-to-s1-from-s7')?.addEventListener('click', () => showScreen('s1'));
document.querySelector('#screen-7 .payment-card img[src*="J3zaJSU.png"]')?.parentElement.addEventListener('click', () => showScreen('s8'));
document.getElementById('back-to-s7')?.addEventListener('click', () => showScreen('s7'));
document.getElementById('back-to-s7-from-s8')?.addEventListener('click', () => showScreen('s7'));

// أزرار التحقق والانتقال من 8 إلى 9
document.querySelector('#screen-8 button')?.addEventListener('click', checkAndGoToS9);
document.getElementById('btn-pay-s8')?.addEventListener('click', checkAndGoToS9);

if (document.getElementById("back-to-s8")) { document.getElementById("back-to-s8").onclick = () => showScreen("s8"); }
document.getElementById('cancel-merchant-s9')?.addEventListener('click', () => showScreen('s7'));
document.getElementById('back-from-s10')?.addEventListener('click', showS1WithLoader);
document.getElementById('finish-merchant-payment')?.addEventListener('click', showS1WithLoader);

/***********************
 * 4. نظام الإشعارات وكشف الحساب
 ***********************/
function updateNotificationBadge() {
    const notifBadge = document.getElementById('notif-badge');
    const list = JSON.parse(localStorage.getItem('bank_notifications')) || [];
    if (notifBadge) {
        const isRead = localStorage.getItem('notifications_read') === 'true';
        notifBadge.style.display = 'flex';
        notifBadge.innerText = (isRead || list.length === 0) ? "0" : list.length.toString();
    }
}

function renderNotificationsPage() {
    const container = document.getElementById('notifications-list');
    const list = JSON.parse(localStorage.getItem('bank_notifications')) || [];
    if (!container) return;
    if (list.length === 0) {
        container.innerHTML = '<p style="text-align:center; padding:50px; color:#888;">لا توجد إشعارات حالية</p>';
        return;
    }
    container.innerHTML = list.map(item => `
        <div class="notification-card" style="padding: 15px 20px; border-bottom: 1px solid #eee; background: white; direction: rtl;">
            <div style="display: flex; justify-content: space-between; align-items: center; color: #3b5998; font-weight: bold; font-size: 15px; margin-bottom: 4px;">
                <span>${item.title}</span>
                <span style="font-family: 'Cairo', sans-serif; font-weight: normal; font-size: 13px;">${toHindiNumbers(item.date)}</span>
            </div>
            <div style="text-align: right; font-size: 14px; color: #333; line-height: 1.4;">
                ${item.desc}
            </div>
        </div>`).join('');
}

if (document.getElementById('open-notifications')) {
    document.getElementById('open-notifications').onclick = () => {
        localStorage.setItem('notifications_read', 'true');
        syncLocalData(['notifications_read']); 
        updateNotificationBadge(); 
        showScreen('notif'); 
        renderNotificationsPage(); 
    };
}

// إضافة حركة في كشف الحساب (محدثة لدعم الحفظ التلقائي)
function addStatementEntry(descText, amountStr, dateStr = null, doSave = true) {
    const tbody = document.getElementById('statement-tbody');
    if (!tbody) return;
    
    // تحديد التاريخ (إما ممرر من الذاكرة أو تاريخ اليوم للحركات الجديدة)
    let finalDate = dateStr;
    if (!finalDate) {
        const today = new Date();
        finalDate = String(today.getDate()).padStart(2, '0') + '/' + 
                    String(today.getMonth() + 1).padStart(2, '0') + '/' + 
                    today.getFullYear();
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td class="acc-col-date">${finalDate}</td>
        <td class="acc-col-desc">
            <span>${descText}</span>
        </td>
        <td class="acc-col-amount">${amountStr}</td>
    `;
    tr.setAttribute('data-currency', 'shekel');
    
    // إضافة الصف إلى أعلى الجدول
    tbody.insertBefore(tr, tbody.firstChild);

    // حفظ الحركة في localStorage إذا كانت حركة جديدة (doSave = true)
    if (doSave) {
        let statements = JSON.parse(localStorage.getItem('bank_statements')) || [];
        // إضافة الحركة الجديدة في بداية المصفوفة (الأحدث أولاً)
        statements.unshift({ date: finalDate, desc: descText, amount: amountStr });
        localStorage.setItem('bank_statements', JSON.stringify(statements));
        syncLocalData(['bank_statements']);
    }
}

// دالة جديدة لتحميل حركات الحساب المحفوظة مسبقاً
function loadSavedStatements() {
    const statements = JSON.parse(localStorage.getItem('bank_statements')) || [];
    // نعكس المصفوفة لنبدأ بإضافة الأقدم ثم الأحدث، ليبقى الأحدث دائماً في أعلى الجدول
    statements.reverse().forEach(stmt => {
        addStatementEntry(stmt.desc, stmt.amount, stmt.date, false);
    });
}

// تحديث الرصيد في جميع الأماكن
function updateAllBalances(newBalance) {
    const balanceElements = [
        document.querySelector('.amount-number-system'),
        ...document.querySelectorAll('.acc-balance-text')
    ];
    balanceElements.forEach(el => {
        if(el) el.textContent = parseFloat(newBalance).toFixed(2);
    });
}

/***********************
 * 5. العمليات المالية (لصديق) وحساب العمولة
 ***********************/
let currentBalance = parseFloat(localStorage.getItem('user_balance')) || 44.91;

const amountInput = document.querySelector('.amount-input');
const recipientNameEl = document.getElementById('recipientName');
const recipientPhoneEl = document.getElementById('recipientPhone');
const recipientIcon = document.getElementById('recipientIcon');

let currentCommission = 0; 

amountInput?.addEventListener('input', () => {
    const val = parseFloat(amountInput.value) || 0;
    document.getElementById('amount-s5').textContent = val.toFixed(2) + ' ILS';
});

document.getElementById('confirmBtn')?.addEventListener('click', function() {
    const val = parseFloat(amountInput.value) || 0;
    
    // التوقف بصمت إذا كان المبلغ 0
    if (val === 0) return;

    const total = val + currentCommission; 
    if (total > currentBalance) return alert('الرصيد غير كافٍ');

    currentBalance -= total;
    localStorage.setItem('user_balance', currentBalance.toFixed(2));
    syncLocalData(['user_balance']);
    updateAllBalances(currentBalance);

    const random9DigitCode = Math.floor(100000000 + Math.random() * 900000000);

    const newNotif = {
        title: "الدفع لصديق",
        date: new Date().toLocaleDateString('en-GB'),
        desc: `تحويل دفع لصديق: ${recipientNameEl.textContent}، بمبلغ <b>${total.toFixed(2)} ILS</b>`
    };
    
    const list = JSON.parse(localStorage.getItem('bank_notifications')) || [];
    list.unshift(newNotif);
    localStorage.setItem('bank_notifications', JSON.stringify(list));
    localStorage.setItem('notifications_read', 'false');
    syncLocalData(['bank_notifications', 'notifications_read']);

    // إدراج في كشف الحساب التلقائي
    const stmtDesc = `دفع ل ${recipientNameEl.textContent}، رقم الحركة : ${random9DigitCode}`;
    addStatementEntry(stmtDesc, total.toFixed(1) + '-');

    document.getElementById('display-name').textContent = recipientNameEl.textContent;
    document.getElementById('display-phone').textContent = recipientPhoneEl.textContent || '---';
    document.getElementById('display-amount').textContent = total.toFixed(1) + ' ILS';
    document.getElementById('display-code').textContent = random9DigitCode;

    showScreen('s6');
    updateNotificationBadge();
});

/***********************
 * 6. اختيار البنك (والتحقق من المستلم وتطبيق العمولة)
 ***********************/
const bottomSheet = document.getElementById('bottomSheet');
const overlay = document.getElementById('overlay');
const phoneInput = document.querySelector('#screen-4 .input-field');

async function validateRecipientPhoneField() {
    const phoneVal = phoneInput?.value.trim() || '';
    if (!phoneVal || phoneVal === '0') return;
    const contact = await findContactByPhoneFresh(phoneVal);
    if (contact?.name) {
        localStorage.setItem('recipient_phone', phoneVal);
        localStorage.setItem('recipient_name', contact.name);
    } else {
        localStorage.removeItem('recipient_name');
        localStorage.setItem('recipient_phone', phoneVal);
    }
}
phoneInput?.addEventListener('blur', validateRecipientPhoneField);

const merchantPhoneField = document.getElementById('merchant-phone-input');
merchantPhoneField?.addEventListener('blur', async () => {
    const phoneVal = merchantPhoneField.value.trim();
    if (!phoneVal || phoneVal === '0') return;
    const contact = await findContactByPhoneFresh(phoneVal);
    if (contact?.name) {
        localStorage.setItem('merchant_phone', phoneVal);
        localStorage.setItem('merchant_name', contact.name);
        updateS9Inputs(phoneVal, contact.name);
    } else {
        localStorage.removeItem('merchant_name');
        localStorage.setItem('merchant_phone', phoneVal);
        updateS9Inputs(phoneVal, '');
        showVerifyModal();
    }
});

document.getElementById('openSheetBtn')?.addEventListener('click', () => {
    bottomSheet.style.bottom = "0";
    overlay.style.display = "block";
});

const closeSheet = () => {
    bottomSheet.style.bottom = "-100%";
    overlay.style.display = "none";
};

document.querySelector('.close-text')?.addEventListener('click', closeSheet);
overlay?.addEventListener('click', closeSheet);

document.querySelectorAll('.bank-item').forEach(item => {
    item.addEventListener('click', async () => {
        const val = parseFloat(amountInput.value) || 0;
        const phoneVal = phoneInput.value.trim();

        // التوقف بصمت إذا كان المبلغ 0 أو رقم الموبايل فارغاً/0
        if (val === 0 || phoneVal === "" || phoneVal === "0") {
            return; 
        }

        closeSheet();
        const bankType = item.dataset.target;
        if (recipientIcon) {
            if (bankType === 'palpay') {
                recipientIcon.innerHTML = `<img src="assets/service-icon.svg" width="48">`;
            } else if (bankType === 'palpay-wallet') {
                recipientIcon.innerHTML = `<img src="assets/service-icon.svg" width="48">`;
            }
        }

        if (bankType === 'palpay') {
            currentCommission = calcPalPayCommission(val);
        } else {
            currentCommission = 0;
        }

        document.getElementById('amount-s5').textContent = val.toFixed(2) + ' ILS';
        document.getElementById('commission-s5').textContent = currentCommission.toFixed(2) + ' ILS';
        document.getElementById('total-s5').textContent = (val + currentCommission).toFixed(2) + ' ILS';

        const contact = await findContactByPhoneFresh(phoneVal);

        if (contact && contact.name) {
            recipientNameEl.textContent = contact.name;
            recipientPhoneEl.textContent = phoneVal;
            // حفظ آخر مستلم تم التحقق منه، دون اختلاق اسم أو استخدام اسم قديم لرقم آخر.
            localStorage.setItem('recipient_name', contact.name);
            localStorage.setItem('recipient_phone', phoneVal);
            showScreen('s5');
        } else {
            showVerifyModal();
        }
    });
});

document.getElementById('verifyOkBtn')?.addEventListener('click', () => {
    document.getElementById('verifyModal').style.display = 'none';
});

/***********************
 * 7. نظام السحب المتطور والحفظ التلقائي
 ***********************/
let startX = 0;
let startY = 0;
let lastSwipeTime = 0;
let autoSaveTimer;
let swipeDownCount = 0;
let swipeDownTimer = null;

function checkMainScreen() {
    const loginScreen = document.getElementById('screen-login');
    return loginScreen && loginScreen.style.display !== 'none';
}

document.addEventListener('touchstart', e => {
    startX = e.changedTouches[0].screenX;
    startY = e.changedTouches[0].screenY;
}, {passive: true});

document.addEventListener('touchend', e => {
    const diffX = e.changedTouches[0].screenX - startX;
    const diffY = e.changedTouches[0].screenY - startY;
    const now = Date.now();

    // السحب من أعلى لأسفل في الشاشة الرئيسية 3 مرات متتالية → الرجوع لشاشة الدخول
    const screen1 = document.getElementById('screen-1');
    const isScreen1Visible = screen1 && screen1.style.display !== 'none';
    if (isScreen1Visible && diffY > 80 && Math.abs(diffX) < 80) {
        const now2 = Date.now();
        if (now2 - lastSwipeTime < 800) {
            swipeDownCount++;
        } else {
            swipeDownCount = 1;
        }
        lastSwipeTime = now2;
        if (swipeDownCount >= 3) {
            swipeDownCount = 0;
            showScreen('login');
        }
        return;
    }

    if (!checkMainScreen()) return;

    if (diffX > 60) {
        if (now - lastSwipeTime < 500) openPanel('hidden-right');
        lastSwipeTime = now;
    }
    if (diffX < -60) {
        if (now - lastSwipeTime < 500) openPanel('hidden-left');
        lastSwipeTime = now;
    }
}, {passive: true});

function openPanel(id) {
    const p = document.getElementById(id);
    if (!p) return;

    if (id === 'hidden-right') {
        document.getElementById('edit-name').value = localStorage.getItem('user_name') || "";
        document.getElementById('edit-balance').value = localStorage.getItem('user_balance') || "";
        p.style.right = "0px";
    } else {
        document.getElementById('merchant-name-input').value = localStorage.getItem('merchant_name') || "";
        document.getElementById('merchant-phone-input-edit').value = localStorage.getItem('merchant_phone') || "";
        document.getElementById('recipient-name-input').value = localStorage.getItem('recipient_name') || "";
        document.getElementById('recipient-phone-input').value = localStorage.getItem('recipient_phone') || "";
        p.style.left = "0px";

        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(() => saveLeftData(true), 20000);
    }
}

document.getElementById('save-right').onclick = function() {
    const name = document.getElementById('edit-name').value;
    const bal = document.getElementById('edit-balance').value;
    localStorage.setItem('user_name', name);
    localStorage.setItem('user_balance', bal);
    syncLocalData(['user_name', 'user_balance']);
    currentBalance = parseFloat(bal) || 0; 
    
    const s1Name = document.querySelector('.welcome-text');
    if(s1Name) s1Name.innerHTML = `مرحباً، ${name}`;
    updateAllBalances(currentBalance);
    
    document.getElementById('hidden-right').style.right = "-320px";
};

function saveLeftData(isAuto = false) {
    const mName = document.getElementById('merchant-name-input').value.trim();
    const mPhone = document.getElementById('merchant-phone-input-edit').value.trim();
    const rName = document.getElementById('recipient-name-input').value.trim();
    const rPhone = document.getElementById('recipient-phone-input').value.trim();

    // حفظ الحقول نفسها فوراً محلياً.
    localStorage.setItem('merchant_name', mName);
    localStorage.setItem('merchant_phone', mPhone);
    localStorage.setItem('recipient_name', rName);
    localStorage.setItem('recipient_phone', rPhone);
    syncLocalData(['merchant_name', 'merchant_phone', 'recipient_name', 'recipient_phone']);

    // بناء دليل رقم ← اسم، وهو المصدر الوحيد لعرض الاسم بعد إدخال الرقم.
    if (mName && mPhone) saveContactMapping(mName, mPhone, 'merchant');
    if (rName && rPhone) saveContactMapping(rName, rPhone, 'recipient');

    const s8Input = document.getElementById('merchant-phone-input');
    if(s8Input) s8Input.value = mPhone;

    clearTimeout(autoSaveTimer);
    if (!isAuto) document.getElementById('hidden-left').style.left = '-320px';
}


if(document.getElementById('save-left')) {
    document.getElementById('save-left').onclick = () => saveLeftData(false);
}

// حفظ تلقائي أثناء الكتابة، وليس فقط عند الضغط على "حفظ الآن".
['recipient-name-input','recipient-phone-input','merchant-name-input','merchant-phone-input-edit'].forEach(id => {
    const el = document.getElementById(id);
    el?.addEventListener('input', () => {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(() => saveLeftData(true), 350);
    });
});

document.querySelectorAll('.hidden-panel-custom').forEach(panel => {
    panel.onclick = (e) => e.stopPropagation();
});

/***********************
 * 8. الـ QR Scanner والتحقق
 ***********************/
let html5QrCode;
const readerContainer = document.getElementById('reader-container');
const flashBtn = document.getElementById('flash-toggle-btn');
const closeBtnText = document.getElementById('close-scanner-text');
const scanImageBtn = document.getElementById('scan-image-btn');
const fileInput = document.getElementById('qr-input-file');

document.querySelectorAll('.qr-trigger').forEach(img => {
    
    img.addEventListener('click', startScanner);
});

scanImageBtn?.addEventListener('click', () => { fileInput.click(); });

fileInput?.addEventListener('change', async (e) => {
    if (e.target.files.length === 0) return;
    const imageFile = e.target.files[0];
    try {
        if (typeof Html5Qrcode === "undefined") { alert("قارئ QR غير مضمّن في النسخة المحلية؛ استخدم الإدخال اليدوي."); return; }
        if (!html5QrCode) html5QrCode = new Html5Qrcode("reader");
        if (html5QrCode.isScanning) await html5QrCode.stop();
        const decodedText = await html5QrCode.scanFile(imageFile, true);
        
        const contact = await findContactByPhoneFresh(decodedText.trim());
        if (!contact || !contact.name) {
            showVerifyModal();
            stopScanner();
            return;
        }
        localStorage.setItem('merchant_name', contact.name);
        localStorage.setItem('merchant_phone', decodedText.trim());
        updateS9Inputs();
        stopScanner();
        showScreen('s9'); 
    } catch (err) {
        alert("لم يتم العثور على QR واضح في الصورة");
        console.error(err);
    }
});

async function startScanner() {
    if (typeof Html5Qrcode === "undefined") {
        alert("المسح بالكاميرا غير متاح في النسخة المحلية. استخدم الإدخال اليدوي.");
        return;
    }
    readerContainer.style.display = 'block';
    if (!html5QrCode) html5QrCode = new Html5Qrcode("reader");
    html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        async (decodedText) => {
            const contact = await findContactByPhoneFresh(decodedText.trim());
            if (!contact || !contact.name) {
                showVerifyModal();
                stopScanner();
                return;
            }
            localStorage.setItem('merchant_name', contact.name);
            localStorage.setItem('merchant_phone', decodedText.trim());
            updateS9Inputs();
            stopScanner();
            showScreen('s9'); 
        }
    ).catch(err => {
        // الكاميرا غير متاحة — افتح مباشرة اختيار الصورة بدون رسالة خطأ
        console.warn("الكاميرا غير متاحة، انتقل لاختيار صورة:", err);
        fileInput.click();
    });
}

function stopScanner() {
    if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().then(() => { readerContainer.style.display = 'none'; });
    } else {
        readerContainer.style.display = 'none';
    }
}

document.getElementById('open-scanner-btn')?.addEventListener('click', startScanner);
closeBtnText?.addEventListener('click', stopScanner);

/***********************
 * 9. تهيئة عند التحميل
 ***********************/
window.onload = () => {
    updateNotificationBadge();
    
    // استدعاء الحركات المالية المحفوظة في كشف الحساب
    loadSavedStatements();

    const savedBal = localStorage.getItem('user_balance');
    if(savedBal) {
        updateAllBalances(savedBal);
        // ضمان أن حساب الشيكل في تفاصيل الحساب يعرض نفس الرصيد الرئيسي.
        const balance = parseFloat(savedBal);
        if (Number.isFinite(balance) && accountCurrencyData.shekel) {
            accountCurrencyData.shekel.available = balance.toFixed(2);
            accountCurrencyData.shekel.current = balance.toFixed(2);
        }
    }

    const savedName = localStorage.getItem('user_name');
    const s1Name = document.querySelector('.welcome-text');
    if(savedName && s1Name) s1Name.innerHTML = `مرحباً، ${savedName}`;
    
    const grid = document.getElementById('services-grid');
    if(grid) {
        Array.from(grid.children).forEach((item, i) => item.style.display = 'flex');
    }
};

document.getElementById('toggle-services')?.addEventListener('click', function() {
    const grid = document.getElementById('services-grid');
    const items = Array.from(grid.children);
    const isShowingMore = this.innerText.includes("أقل");
    items.forEach((item, i) => { if (i >= 4) item.style.display = isShowingMore ? 'none' : 'flex'; });
    this.innerText = isShowingMore ? `عرض الكل (${items.length})` : "عرض أقل";
});

/***********************
 * 10. العمليات الديناميكية لشاشة 9 و 10 والمودال (التاجر)
 ***********************/
const nextBtnS9 = document.getElementById('next-to-confirm-merchant');
const merchantModal = document.getElementById('merchant-confirm-modal');
const cancelMerchantBtn = document.getElementById('cancel-merchant-btn');
const confirmMerchantBtn = document.getElementById('confirm-merchant-btn');

if (nextBtnS9) {
    nextBtnS9.addEventListener('click', async (e) => {
        if(e) e.preventDefault(); // لمنع الإرسال الافتراضي
        const amountField = document.getElementById('amount-s9');
        const amount = amountField ? amountField.value.trim() : "0";
        const numericAmount = parseFloat(amount);

        // التوقف بصمت إذا كان المبلغ فارغاً أو 0
        if (amount === "" || isNaN(numericAmount) || numericAmount === 0) {
            return; 
        }

        const merchantContact = await findContactByPhoneFresh(localStorage.getItem('merchant_phone') || '');
        if (!merchantContact || !merchantContact.name) { updateS9Inputs(localStorage.getItem('merchant_phone') || '', ''); showVerifyModal(); return; }
        const mName = merchantContact.name;
        updateS9Inputs(localStorage.getItem('merchant_phone') || '', mName);

        const modalAmountText = document.getElementById('modal-amount-text');
        const modalMerchantText = document.getElementById('modal-merchant-text');
        const modalTotalText = document.getElementById('modal-total-text');

        if(modalAmountText) modalAmountText.innerText = amount + " شيكل";
        if(modalMerchantText) modalMerchantText.innerText = mName;
        if(modalTotalText) modalTotalText.innerText = numericAmount.toFixed(1) + " ILS";

        merchantModal.style.display = 'flex';
    });
}

if (cancelMerchantBtn) {
    cancelMerchantBtn.addEventListener('click', () => {
        merchantModal.style.display = 'none';
    });
}

if (confirmMerchantBtn) {
    confirmMerchantBtn.addEventListener('click', () => {
        const amountField = document.getElementById('amount-s9');
        const amount = parseFloat(amountField ? amountField.value : "0");
        
        if (amount > currentBalance) return alert('الرصيد غير كافٍ');
        
        currentBalance -= amount;
        localStorage.setItem('user_balance', currentBalance.toFixed(2));
    syncLocalData(['user_balance']);
        updateAllBalances(currentBalance);

        merchantModal.style.display = 'none';
        
        const merchantContact = findContactByPhone(localStorage.getItem('merchant_phone') || '');
        const mName = merchantContact?.name || '';
        if (!mName) return showVerifyModal();

        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const letters = chars.charAt(Math.floor(Math.random() * 26)) + chars.charAt(Math.floor(Math.random() * 26));
        const numbers = Math.floor(10000000 + Math.random() * 90000000);
        const refNum = letters + numbers; // الرقم المرجعي

        const random7Digit = Math.floor(1000000 + Math.random() * 9000000); // رقم 7 خانات عشوائي

        // إدراج العملية في كشف الحساب
        const stmtDesc = `دفع ل ${mName},<br>رقم الحركة :${random7Digit},<br>${refNum}`;
        addStatementEntry(stmtDesc, parseFloat(amount || 0).toFixed(1) + '-');

        const today = new Date();
        const dateStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');

        const s10Vals = document.querySelectorAll('#screen-10 .value-text');
        
        const elMerchant = document.getElementById('s10-merchant-name');
        if(elMerchant) elMerchant.innerText = mName; else if(s10Vals[0]) s10Vals[0].innerText = mName;
        
        const elPos = document.getElementById('s10-pos-name');
        if(elPos) elPos.innerText = mName; else if(s10Vals[1]) s10Vals[1].innerText = mName;
        
        const elAmt = document.getElementById('s10-amount');
        if(elAmt) elAmt.innerText = parseFloat(amount || 0).toFixed(1); else if(s10Vals[2]) s10Vals[2].innerText = parseFloat(amount || 0).toFixed(1);
        
        const elRef = document.getElementById('s10-ref');
        if(elRef) elRef.innerText = refNum; else if(s10Vals[4]) s10Vals[4].innerText = refNum;
        
        const elDate = document.getElementById('s10-date');
        if(elDate) elDate.innerText = dateStr; else if(s10Vals[5]) s10Vals[5].innerText = dateStr;

        showScreen('s10'); 
    });
}

/***********************
 * 11. لقطة الشاشة (الشاشة 10) كاملة بما فيها الأزرار
 ***********************/
const s10Img = document.getElementById('s10-image') || document.querySelector('#screen-10 .icon-box img');
if(s10Img) {
    s10Img.addEventListener('click', () => {
        if (typeof html2canvas === 'undefined') {
            alert('يرجى التأكد من إضافة مكتبة html2canvas في ملف index.html لتعمل ميزة تصوير الشاشة.');
            return;
        }

        const screen10 = document.getElementById('screen-10');

        html2canvas(screen10, { scale: 2 }).then(canvas => {
            const link = document.createElement('a');
            link.download = 'Receipt_' + new Date().getTime() + '.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
        }).catch(err => {
            console.error("خطأ في التقاط الشاشة", err);
        });
    });
}

/***********************
 * 12. نظام تسجيل الدخول (مع تقييد أرقام فقط)
 ***********************/
const confirmModal = document.getElementById('confirmModal');
const cancelBtn = document.querySelector('.cancel-btn');
const codeInputs = document.querySelectorAll('.code-inputs input');
const allowedPasswords = ['0000']; // رمز دخول تجريبي معلن — ليس كلمة مرور مصرفية

// زر "استخدم رمز التأكيد" يفتح مربع تسجيل الدخول مباشرة
const otpLoginBtn = document.getElementById('otp-login-btn');
if (otpLoginBtn) {
    otpLoginBtn.addEventListener('click', () => {
        if (confirmModal) {
            confirmModal.style.display = 'flex';
            if (codeInputs.length > 0) codeInputs[0].focus();
        }
    });
}

if(document.getElementById('screen-login')) {
    setTimeout(() => {
        if(confirmModal) {
            confirmModal.style.display = 'flex';
            if(codeInputs.length > 0) codeInputs[0].focus();
        }
    }, 3000);
}

if(cancelBtn) {
    cancelBtn.addEventListener('click', () => {
        confirmModal.style.display = 'none';
    });
}

codeInputs.forEach((input, index) => {
    input.addEventListener('keypress', (e) => {
        if (!/[0-9]/.test(e.key)) e.preventDefault();
    });

    input.addEventListener('input', (e) => {
        e.target.value = e.target.value.replace(/[^0-9]/g, '');
        if (e.target.value === '') return;

        if (e.target.value.length === 1) {
            input.dataset.realValue = e.target.value;
            input.value = "*";
            
            if (index < codeInputs.length - 1) codeInputs[index + 1].focus();
            else setTimeout(checkPassword, 100);
        }
    });
    
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace') {
            input.value = '';
            input.dataset.realValue = '';
            if (index > 0) codeInputs[index - 1].focus();
        }
    });
});

function checkPassword() {
    let password = "";
    codeInputs.forEach(input => password += (input.dataset.realValue || ""));
    
    if (allowedPasswords.includes(password)) {
        confirmModal.style.display = 'none';
        codeInputs.forEach(input => { input.value = ''; input.dataset.realValue = ''; });

        showScreen('s1'); 
    } else {
        codeInputs.forEach(input => { input.value = ''; input.dataset.realValue = ''; });
        codeInputs[0].focus();
    }
}

/***********************
 * سحب للأسفل 3 مرات متتالية = العودة لشاشة تسجيل الدخول
 ***********************/
(function() {
    let pullStartY = 0;
    let pullLastTime = 0;
    let pullCount = 0;
    const PULL_THRESHOLD = 80;  // px للأسفل
    const PULL_GAP = 800; // ms بين السحبات المتتالية

    document.addEventListener('touchstart', function(e) {
        pullStartY = e.changedTouches[0].clientY;
    }, { passive: true });

    document.addEventListener('touchend', function(e) {
        const loginScreen = document.getElementById('screen-login');
        if (loginScreen && loginScreen.style.display !== 'none') return;

        const endY = e.changedTouches[0].clientY;
        const diff = endY - pullStartY;

        if (diff > PULL_THRESHOLD) {
            const now = Date.now();
            if (now - pullLastTime < PULL_GAP) {
                pullCount++;
            } else {
                pullCount = 1;
            }
            pullLastTime = now;

            if (pullCount >= 3) {
                pullCount = 0;
                document.querySelectorAll('.app-screen, .payment-view, .friends-view').forEach(s => {
                    s.style.display = 'none';
                });
                loginScreen.style.display = 'block';
            }
        }
    }, { passive: true });
})();


/***********************
 * قائمة شاشة تسجيل الدخول
 ***********************/
(function initLoginMenu() {
    const trigger = document.getElementById('login-menu-trigger');
    const panel = document.getElementById('login-menu-panel');
    const overlay = document.getElementById('login-menu-overlay');
    const closeBtn = document.getElementById('close-login-menu');
    const content = document.getElementById('login-menu-content');
    const contentImage = document.getElementById('login-menu-content-image');
    const closeContentBtn = document.getElementById('close-login-menu-content');

    if (!trigger || !panel || !overlay || !content || !contentImage) return;

    const images = {
        'about-app': {
            src: 'assets/service-icon.svg',
            alt: 'عن التطبيق'
        },
        'login': {
            src: 'assets/service-icon.svg',
            alt: 'تسجيل الدخول'
        },
        'about-wallet': {
            src: 'assets/service-icon.svg',
            alt: 'عن محفظتي'
        },
        'contact': {
            src: 'assets/service-icon.svg',
            alt: 'اتصل بنا'
        },
        'privacy': {
            src: 'assets/service-icon.svg',
            alt: 'سياسة الخصوصية'
        }
    };

    const openMenu = () => {
        panel.classList.add('active');
        overlay.classList.add('active');
        overlay.setAttribute('aria-hidden', 'false');
    };

    const closeMenu = () => {
        panel.classList.remove('active');
        overlay.classList.remove('active');
        overlay.setAttribute('aria-hidden', 'true');
    };

    const closeContent = () => {
        content.classList.remove('active');
        content.setAttribute('aria-hidden', 'true');
        contentImage.removeAttribute('src');
        closeMenu();
    };

    trigger.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openMenu();
    });

    overlay.addEventListener('click', closeMenu);
    closeBtn?.addEventListener('click', closeMenu);

    panel.querySelectorAll('.login-menu-item').forEach(item => {
        item.addEventListener('click', () => {
            const key = item.getAttribute('data-login-menu-screen');
            const data = images[key];
            if (!data) return;

            closeMenu();

            if (key === 'login') {
                return;
            }

            contentImage.src = data.src;
            contentImage.alt = data.alt;
            content.classList.add('active');
            content.setAttribute('aria-hidden', 'false');
        });
    });

    closeContentBtn?.addEventListener('click', closeContent);

    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        if (content.classList.contains('active')) {
            closeContent();
        } else {
            closeMenu();
        }
    });
})();

/***********************
 * القائمة الجانبية الرئيسية
 ***********************/
(function initMainMenu() {
    const menuBars = document.getElementById('menu-trigger');
    const mainMenu = document.getElementById('main-menu');
    const menuOverlay = document.createElement('div');
    menuOverlay.className = 'menu-overlay';
    document.body.appendChild(menuOverlay);

    // فتح القائمة عند النقر على الثلاث شرطات في الشاشة 1 فقط
    if (menuBars) {
        menuBars.addEventListener('click', function() {
            mainMenu.classList.add('active');
            menuOverlay.classList.add('active');
        });
    }

    // إغلاق القائمة عند النقر خارجها
    menuOverlay.addEventListener('click', function() {
        mainMenu.classList.remove('active');
        menuOverlay.classList.remove('active');
    });

    // إغلاق القائمة عند النقر على عنصر من عناصرها
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            mainMenu.classList.remove('active');
            menuOverlay.classList.remove('active');
            
            // معالجة الأفعال المتعلقة بكل عنصر قائمة
            const action = this.getAttribute('data-action');
            if (action === 'home') {
                showScreen('s1');
            } else if (action === 'check-code') {
                document.getElementById('check-code-screen').classList.add('active');
            } else if (action === 'pay-friend') {
                showScreen('s3');
            } else if (action === 'pay-merchant') {
                showScreen('s7');
            } else if (action === 'qr-scan') {
                startScanner();
            }
        });
    });
})();

/***********************
 * شاشة "إنشاء USSD QR" (كاملة الصفحة) — تُفتح من صورة إنشاء USSD QR
 ***********************/
(function initUssdQrScreen() {
    const trigger = document.getElementById('ussd-qr-trigger');
    const screen = document.getElementById('ussdQrScreen');
    const closeIcon = document.getElementById('closeUssdQr');

    if (!trigger || !screen) return;

    const openScreen = () => { screen.classList.add('active'); };
    const closeScreen = () => { screen.classList.remove('active'); };

    trigger.addEventListener('click', openScreen);
    closeIcon?.addEventListener('click', closeScreen);
})();

/***********************
 * شاشة "عن بال باي" (كاملة الصفحة) — تُفتح من صورة عن محفظتي
 ***********************/
(function initAboutUsScreen() {
    const trigger = document.getElementById('about-us-trigger');
    const screen = document.getElementById('aboutUsScreen');
    const closeIcon = document.getElementById('closeAboutUs');

    if (!trigger || !screen) return;

    const openScreen = (e) => {
        e.stopPropagation();
        screen.classList.add('active');
    };
    const closeScreen = () => { screen.classList.remove('active'); };

    trigger.addEventListener('click', openScreen);
    closeIcon?.addEventListener('click', closeScreen);
})();

/***********************
 * شاشة "تواصل معنا" (كاملة الصفحة)
 ***********************/
(function initContactUsScreen() {
    const trigger = document.getElementById('contact-us-trigger');
    const screen = document.getElementById('contactUsScreen');
    const closeIcon = document.getElementById('closeContactUs');

    if (!trigger || !screen) return;

    const openScreen = () => { screen.classList.add('active'); };
    const closeScreen = () => { screen.classList.remove('active'); };

    trigger.addEventListener('click', openScreen);
    closeIcon?.addEventListener('click', closeScreen);
})();

/***********************
 * شاشة "فحص كود الصرف" (كاملة الصفحة)
 ***********************/
(function initCheckCodeScreen() {
    const screen = document.getElementById('check-code-screen');
    const closeIcon = document.getElementById('close-check-code');
    const checkBtn = document.getElementById('checkCodeBtn');
    const codeInput = document.getElementById('codeInput');
    const resultsDiv = document.getElementById('checkCodeResults');
    const noResultsDiv = document.getElementById('noResults');

    if (!screen) return;

    const closeScreen = () => { screen.classList.remove('active'); };
    
    // البيانات الوهمية للاختبار
    const mockData = {
        '1234': {
            name: 'محمد أحمد',
            id: '123456789',
            code: '1234',
            phone: '0566884400',
            org: 'وزارة الصحة',
            amount: '500 شيقل'
        },
        '5678': {
            name: 'فاطمة علي',
            id: '987654321',
            code: '5678',
            phone: '0599887766',
            org: 'وزارة التعليم',
            amount: '1000 شيقل'
        },
        '9999': {
            name: 'سالم محمود',
            id: '456789012',
            code: '9999',
            phone: '0572334455',
            org: 'بلدية رام الله',
            amount: '250 شيقل'
        }
    };

    closeIcon?.addEventListener('click', closeScreen);

    checkBtn?.addEventListener('click', () => {
        const code = codeInput.value.trim();
        
        if (!code) {
            resultsDiv.style.display = 'none';
            noResultsDiv.style.display = 'block';
            return;
        }

        if (mockData[code]) {
            const data = mockData[code];
            document.getElementById('resultName').textContent = data.name;
            document.getElementById('resultId').textContent = data.id;
            document.getElementById('resultCode').textContent = data.code;
            document.getElementById('resultPhone').textContent = data.phone;
            document.getElementById('resultOrg').textContent = data.org;
            document.getElementById('resultAmount').textContent = data.amount;
            
            resultsDiv.style.display = 'block';
            noResultsDiv.style.display = 'none';
        } else {
            resultsDiv.style.display = 'none';
            noResultsDiv.style.display = 'block';
        }
    });

    // البحث عند الضغط على Enter
    codeInput?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            checkBtn.click();
        }
    });
})();

/***********************
 * شاشة "فحص كود الصرف" (كاملة الصفحة)
 ***********************/
(function initCheckCodeScreen() {
    const trigger = document.getElementById('check-code-trigger');
    const screen = document.getElementById('check-code-screen');
    const closeIcon = document.getElementById('close-check-code');

    if (!trigger || !screen) return;

    const openScreen = () => {
        // إشارة التحميل تظهر أولاً على الواجهة الحالية، ثم يتم فتح شاشة فحص كود الصرف.
        const currentScreen = document.querySelector(
            '.app-screen[style*="display: block"], .app-screen[style*="display: flex"], .payment-view[style*="display: block"], .payment-view[style*="display: flex"]'
        ) || document.getElementById('screen-1');

        if (!currentScreen) {
            screen.classList.add('active');
            return;
        }

        const oldLoader = currentScreen.querySelector('.check-code-click-loader');
        if (oldLoader) oldLoader.remove();

        const loader = document.createElement('div');
        loader.className = 'check-code-click-loader';
        loader.innerHTML = '<div class="custom-loader"></div>';
        currentScreen.appendChild(loader);

        window.setTimeout(() => {
            loader.remove();
            screen.classList.add('active');
        }, 5000);
    };
    const closeScreen = () => { screen.classList.remove('active'); };

    trigger.addEventListener('click', openScreen);
    closeIcon?.addEventListener('click', closeScreen);
})();
