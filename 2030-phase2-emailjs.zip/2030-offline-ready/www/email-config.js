/*
 * EmailJS client configuration.
 * The EmailJS public key is intended for browser use; never put private API tokens here.
 * These values were present in the supplied earlier project. Confirm they are still active
 * in the EmailJS dashboard before using the optional email buttons.
 */
window.EMAILJS_CONFIG = Object.freeze({
  publicKey: "sZQujmMuXwkE4Gt1Y",
  serviceId: "service_owz5qzf",
  templateId: "template_79ykomn"
});
