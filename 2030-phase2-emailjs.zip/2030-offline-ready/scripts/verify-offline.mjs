import fs from "node:fs";
const files = ["www/index.html", "www/style.css", "www/script.js", "www/email-config.js"];
const combined = files.map(f => fs.readFileSync(f, "utf8")).join("\n");
// The only permitted network request is the user-triggered EmailJS send endpoint.
const withoutAllowedEmail = combined.replaceAll("https://api.emailjs.com/api/v1.0/email/send", "EMAILJS_SEND_ENDPOINT");
const forbidden = [/XMLHttpRequest/i, /sendBeacon/i, /api\.jsonbin\.io/i,
  /ipapi\.co/i, /fetch\s*\(\s*["'`]https?:\/\/(?!api\.emailjs\.com)/i,
  /https?:\/\/(?!localhost|api\.emailjs\.com|maps\.google\.com)/i];
if (forbidden.some(re => re.test(withoutAllowedEmail))) {
  console.error("Offline verification failed: unexpected external request pattern found.");
  process.exit(1);
}
console.log("Offline source check passed; optional EmailJS endpoint is allow-listed.");
