import fs from "node:fs";
const manifest = "android/app/src/main/AndroidManifest.xml";
if (!fs.existsSync(manifest)) throw new Error("Android project not found. Run: npx cap add android");
let xml = fs.readFileSync(manifest, "utf8");
if (!xml.includes("xmlns:tools=")) {
  xml = xml.replace("<manifest ", '<manifest xmlns:tools="http://schemas.android.com/tools" ');
}
const removals = [
  '<uses-permission android:name="android.permission.INTERNET" tools:node="remove" />',
  '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" tools:node="remove" />'
];
for (const item of removals) {
  if (!xml.includes(item)) xml = xml.replace("</manifest>", `    ${item}\n</manifest>`);
}
fs.writeFileSync(manifest, xml);
console.log("Added manifest-merger rules to remove internet/network permissions.");
